package com.example.contactapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AddEditActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit2)
    }
}