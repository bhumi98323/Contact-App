package com.example.contactapp

const val dbName= "contact_database.sql"