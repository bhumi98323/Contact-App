package com.example.contactapp.roomdb.entity

import androidx.room.Entity

@Entity
class Contact(
    var id: Int?,
    var profile: Int?,
    var name: String,
    var phoneNumber: String,
    var email:String,
//    var date : Date

    )